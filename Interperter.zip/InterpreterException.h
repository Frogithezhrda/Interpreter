#pragma once
#include <exception>

//prints what happend
class InterpreterException : public std::exception
{

};
