#pragma once
#include "Type.h"

class Integer : public Type
{
public:
	Integer(const int integer);
	/*
	is printable or not
	input: none
	output: none
	*/
	bool isPrintable() const override;
	std::string toString() const override;

private:
	int _val;
};
