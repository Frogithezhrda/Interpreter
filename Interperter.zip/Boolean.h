#pragma once
#include "Type.h"

class Boolean : public Type
{
public:
	//constructor with value
	Boolean(const bool boolean);
	/*
	is printable or not
	input: none
	output: none
	*/
	bool isPrintable() const override;
	/*
	makes as a string
	input: none
	output: string
	*/
	std::string toString() const override;

private:
	bool _val;

};