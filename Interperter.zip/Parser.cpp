#include "Parser.h"
#include "Void.h"
#include "NameErrorException.h"

static std::unordered_map<std::string, Type*> _variables;


Type* Parser::parseString(std::string str)
{
	Type* type = nullptr;
	//if we start with the space than expceiption
	if (str[0] == ' ' || str[0] == '	')
	{
		throw IndentationException();
	}
	Helper::rtrim(str);
	type = getType(str);
	if (!type)
	{
		//making the assignment
		if (makeAssignment(str))
		{
			type = new Void();
			type->setTemp(true);
		}
		else
		{
			type = getVariableValue(str);
		}
	}
	return type;
}

Type* Parser::getType(std::string& str)
{
	Helper::trim(str);
	Type* type = nullptr;
	//checking for each what it is
	if (Helper::isString(str))
	{
		type = new String(str);
	}
	else if (Helper::isBoolean(str))
	{
		type = new Boolean(str == "True");
	}
	else if (Helper::isInteger(str))
	{
		type = new Integer(stoi(str));
	}
	//setting as temp
	if (type != nullptr)
	{
		type->setTemp(true);
	}
	return type;
}

bool Parser::isLegalVarName(std::string str)
{
	int i = 0;
	if (str.size() > 0)
	{
		//checking if the first is a digit
		if (Helper::isDigit(str[0]))
		{
			return false;
		}
	}
	for (i; i < str.size(); i++)
	{
		//checking if none exist than returning false
		if (!(Helper::isLetter(str[i]) || Helper::isDigit(str[i]) || Helper::isUnderscore(str[i])))
		{
			return false;
		}
	}
	return true;
}

bool Parser::makeAssignment(std::string str)
{
	int equalSign = str.find('=');
	std::string name = "";
	std::string value = "";
	Type* type = nullptr;
	//checking if valid
	if (str[0] != equalSign && str[str.size() - 1] != equalSign && equalSign != std::string::npos)
	{
		//getting the afrter
		name = str.substr(0, equalSign);
		value = str.substr(equalSign + 1, str.size() - equalSign + 1);
		Helper::rtrim(name);
		Helper::trim(value);
		//checking for illegal name
		if (!isLegalVarName(name))
		{
			throw SyntaxException();
		}
		//getting the type of the value
		type = getType(value);
		if (type)
		{
			//removing the temp
			type->setTemp(false);
			_variables[name] = type;
		}
		else if (isLegalVarName(value))
		{
			//deep copy 
			auto srcType = getVariableValue(value);
			std::string srcTypeStr = srcType->toString();
			type = getType(srcTypeStr);
			type->setTemp(false);
			_variables[name] = type;
		}
		else
		{
			throw SyntaxException();
		}
		return true;
	}
	return false;
}

Type* Parser::getVariableValue(std::string str)
{
	//of the variables else throw name error excepetion
	return _variables[str] != nullptr ? _variables[str] : throw NameErrorExcepetion(str);
}

void Parser::cleanVariables()
{
	//cleaning
	for (auto it = _variables.begin(); it != _variables.end(); it++)
	{
		delete it->second;
	}
}
