#include "Sequence.h"

Sequence::Sequence()
{
}
