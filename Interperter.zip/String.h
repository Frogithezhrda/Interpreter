#pragma once
#include "Sequence.h"
#include <string>


class String : public Sequence
{
public:
	String(const std::string& str);
	/*
	is printable or not
	input: none
	output: none
	*/
	virtual bool isPrintable() const override;
	/*
	makes it a string
	inpuit: none
	output: string
	*/
	virtual std::string toString() const override;
private:
	std::string _val;
};
